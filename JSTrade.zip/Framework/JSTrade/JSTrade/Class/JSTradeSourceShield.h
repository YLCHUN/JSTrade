//
//  JSTradeSourceShield.h
//  JSTrade
//
//  Created by YLCHUN on 2017/6/1.
//  Copyright © 2017年 ylchun. All rights reserved.
//
//  源码保护，防止外部获取源代码

void import_JSTradeSourceShield(void);
