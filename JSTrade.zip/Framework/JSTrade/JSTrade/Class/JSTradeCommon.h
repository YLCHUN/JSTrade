//
//  JSTradeCommon.h
//  JSTrade
//
//  Created by YLCHUN on 2017/7/4.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString * const kJSExport_registerKey = @"_JSExportModel_";

