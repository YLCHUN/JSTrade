//
//  ViewController.h
//  WKWebView_JSTrade
//
//  Created by YLCHUN on 2017/3/13.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic) NSString *var2;
@property (nonatomic) NSString *Var2;

//-(void)setVar2:(NSString *)var2;

@end

