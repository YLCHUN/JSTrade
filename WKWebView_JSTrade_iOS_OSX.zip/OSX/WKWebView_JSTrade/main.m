//
//  main.m
//  WKWebView_JSTrade
//
//  Created by YLCHUN on 2017/6/22.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
