//
//  ViewController.m
//  WKWebView_JSTrade
//
//  Created by YLCHUN on 2017/6/22.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
#import <JSTrade/JSHandlerManager.h>

#import "OCModel.h"
#import "OCModel1.h"

@interface ViewController () <WKUIDelegate, WKNavigationDelegate>
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, weak) JSHandlerManager *jsHandler;

@property (nonatomic, strong) id i;
@end

@implementation ViewController

-(WKWebView *)webView {
    if (!_webView) {
        WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
        JSHandlerManager * controller = [[JSHandlerManager alloc] init];
        self.jsHandler = controller;
        OCModel *ocModel = [[OCModel alloc] initWithSpaceName:@"ocModel"];
        OCModel1 *ocModel1 = [[OCModel1 alloc] initWithSpaceName:@"ocModel1"];
        
        [controller addScriptMessageHandlerModel:ocModel];
        [controller addScriptMessageHandlerModel:ocModel1];
        
        [controller addUserScript:[self adjustScreenSizeAndZooming:NO]];
        configuration.userContentController = controller;
        _webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:configuration];
        _webView.UIDelegate = self;
        _webView.navigationDelegate = self;
        [self.view addSubview:_webView];
    }
    return _webView;
}

-(WKUserScript*)adjustScreenSizeAndZooming:(BOOL)zooming {
    // 自适应屏幕宽度js
    NSString *adjustString;
    if (zooming) {
        adjustString = @"var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);";
    }else{
        adjustString = @"var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'); document.getElementsByTagName('head')[0].appendChild(meta);";
    }
    WKUserScript *adjustScript = [[WKUserScript alloc] initWithSource:adjustString injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
    
    return adjustScript;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *urlStr = [[NSBundle mainBundle] pathForResource:@"index.html" ofType:nil];
    NSURL *url = [NSURL fileURLWithPath:urlStr];
    [self.webView loadFileURL:url allowingReadAccessToURL:url];
    
    self.jsHandler[@"jsHandler"] = ^(int i){
        NSLog(@"%d", i);
    };
    [self.webView evaluateJavaScript:@"documentView.webView.mainFrame.javaScriptContext" completionHandler:^(id res, NSError * _Nullable error) {
        
    }];
    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    
    NSAlert *alert = [[NSAlert alloc] init];
    alert.messageText = message;
    [alert addButtonWithTitle:@"确定"];

    NSUInteger action = [alert runModal];
    if (action == NSAlertFirstButtonReturn) {
        completionHandler();
    }
}

@end
