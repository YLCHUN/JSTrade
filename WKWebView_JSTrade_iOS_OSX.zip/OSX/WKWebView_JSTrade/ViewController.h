//
//  ViewController.h
//  WKWebView_JSTrade
//
//  Created by YLCHUN on 2017/6/22.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

