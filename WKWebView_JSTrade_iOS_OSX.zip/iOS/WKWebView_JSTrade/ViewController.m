//
//  ViewController.m
//  WKWebView_JSTrade
//
//  Created by YLCHUN on 2017/3/13.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
#import <JSTrade/JSHandlerManager.h>

#import "OCModel.h"
#import "OCModel1.h"


@interface ViewController ()<WKUIDelegate, WKNavigationDelegate>
@property (nonatomic, retain) WKWebView *webView;
@property (nonatomic, weak) JSHandlerManager *jsHandler;
@end

@implementation ViewController

-(void)dealloc {
    WKUserContentController * controller = self.webView.configuration.userContentController;
    [controller removeAllScriptMessageHandlerModel];
}

-(WKWebView *)webView {
    if (!_webView) {
        WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
        JSHandlerManager * controller = [[JSHandlerManager alloc] init];
        self.jsHandler = controller;
        OCModel *ocModel = [[OCModel alloc] initWithSpaceName:@"ocModel"];
        OCModel1 *ocModel1 = [[OCModel1 alloc] initWithSpaceName:@"ocModel1"];

        [controller addScriptMessageHandlerModel:ocModel];
        [controller addScriptMessageHandlerModel:ocModel1];
        
//        [controller addUserScript:[self adjustScreenSizeAndZooming:NO]];
        configuration.userContentController = controller;
        _webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:configuration];
        _webView.UIDelegate = self;
        _webView.navigationDelegate = self;
        [self.view insertSubview:_webView atIndex:0];
    }
    return _webView;
}

-(WKUserScript*)adjustScreenSizeAndZooming:(BOOL)zooming {
    // 自适应屏幕宽度js
    NSString *adjustString;
    if (zooming) {
        adjustString = @"var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);";
    }else{
        adjustString = @"var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'); document.getElementsByTagName('head')[0].appendChild(meta);";
    }
    WKUserScript *adjustScript = [[WKUserScript alloc] initWithSource:adjustString injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
    
    return adjustScript;
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.webView.backgroundColor = [UIColor whiteColor];

    NSString *urlStr = [[NSBundle mainBundle] pathForResource:@"index.html" ofType:nil];
    NSURL *url = [NSURL fileURLWithPath:urlStr];
    [self.webView loadFileURL:url allowingReadAccessToURL:url];

    
    self.jsHandler[@"jsHandler"] = ^(int i){
        NSLog(@"%d", i);
    };
    [self.webView evaluateJavaScript:@"documentView.webView.mainFrame.javaScriptContext" completionHandler:^(id res, NSError * _Nullable error) {
        
    }];

    NSLog(@"");
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"确定"
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction *action) {
                                                          completionHandler();
                                                      }]];
    
    [self presentViewController:alertController animated:YES completion:^{}];
}

@end
