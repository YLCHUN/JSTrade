//
//  JSModel.m
//  WKWebView_JSTrade
//
//  Created by YLCHUN on 2017/5/28.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import "JSModel.h"

@implementation JSModel

@end
