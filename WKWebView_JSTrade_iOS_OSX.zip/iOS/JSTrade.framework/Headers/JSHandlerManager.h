//
//  JSHandlerManager.h
//  JSTrade
//
//  Created by YLCHUN on 2017/6/7.
//  Copyright © 2017年 ylchun. All rights reserved.
//

#import <WebKit/WKUserContentController.h>

/*
//js调用方式
window.jsHandler(10,'string');

//oc函数
self.jsHandler[@"jsHandler"] = ^(int i, NSString *str ){
    NSLog(@"%d", i);
};
*/


@interface JSHandlerManager : WKUserContentController

- (void)removeObjectForKey:(NSString*)aKey;

- (void)setObject:(id)obj forKeyedSubscript:(NSString*)key;

- (void)removeAllHandler;

@end
